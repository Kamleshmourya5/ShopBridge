﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Common.HelperClass;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;
using System;
using System.Threading.Tasks;

namespace Shopbridge_base.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService productService;
        private readonly ILogger<ProductsController> logger;
        public ProductsController(IProductService _productService, ILogger<ProductsController> _logger)
        {
            this.productService = _productService;
            this.logger = _logger;
        }

       
        /// <summary>
        /// Get the list of Items.
        /// </summary>
        /// <param name="takeCount"></param>
        /// <param name="skipCount"></param>
        /// <returns></returns>
        [HttpGet]   
        [Route("GetAllProductList")]
        public async Task<Result> GetAllProductList(int takeCount, int skipCount)
        {
            try
            {
                var productList = await productService.GetProductList(takeCount,skipCount);
                return Result.Execute(StatusCodes.Status200OK, "List fectched successfully.", productList);
            }catch(Exception ex)
            {
                logger.LogInformation(ex.Message);
                return Result.Execute(StatusCodes.Status400BadRequest, "Something went wrong.", ex.Message);
            }
        }

        /// <summary>
        /// Get the detail of a product 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetProductDetail/{id}")]
        public async Task<Result> GetProduct(int id)
        {
            try
            {
                if (await productService.ProductExists(id))
                {
                    var product = await productService.GetProductById(id);
                    return Result.Execute(StatusCodes.Status200OK, "Product detail fetched.", product);
                }
                else
                {
                    return Result.Execute(StatusCodes.Status400BadRequest, "Product doesn't exists.");
                }
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
                return Result.Execute(StatusCodes.Status400BadRequest, "Something went wrong.", ex.Message);
            }
        }

        /// <summary>
        /// Update item.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateProduct")]
        public async Task<Result> PutProduct(UpdateProductRequest product)
        {
            try
            {
                if (await productService.ProductExists(product.ProductId))
                {
                    var isUpdated = await productService.UpdateItem(product);
                    return Result.Execute(StatusCodes.Status200OK, "Item updated successfully.", isUpdated);
                }
                else
                {
                    return Result.Execute(StatusCodes.Status400BadRequest, "Product doesn't exists.", false);
                }
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
                return Result.Execute(StatusCodes.Status400BadRequest, "Something went wrong.", ex.Message);
            }
        }

        
        /// <summary>
        /// Add item.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddNewProduct")]
        public async Task<Result> PostProduct(AddNewProductRequest product)
        {
            try
            {
                var isAdded = await productService.AddNewItem(product);
                return Result.Execute(StatusCodes.Status200OK, "Item added successfully.", isAdded);
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
                return Result.Execute(StatusCodes.Status400BadRequest, "Something went wrong.", ex.Message);
            }
        }

        /// <summary>
        /// Delete item.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("DeleteProduct/{id}")]
        public async Task<Result> DeleteProduct(int id)
        {
            try
            {
                if (await productService.ProductExists(id))
                {
                    var isDeleted = await productService.DeleteItem(id);
                    return Result.Execute(StatusCodes.Status200OK, "Record deleted successfully.", isDeleted);
                }
                else
                {
                    return Result.Execute(StatusCodes.Status400BadRequest, "Product doesn't exists.", false);
                }
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
                return Result.Execute(StatusCodes.Status400BadRequest, "Something went wrong.", ex.Message);
            }
        }
    }
}
