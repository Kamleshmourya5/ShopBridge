﻿using Shopbridge_base.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Shopbridge_base.Domain.Services.Interfaces
{
    public interface IProductService
    {
        /// <summary>
        /// To Add New Item
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public Task<int> AddNewItem(AddNewProductRequest productRequest);

        /// <summary>
        /// Update Item
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public Task<bool> UpdateItem(UpdateProductRequest product);

        /// <summary>
        /// Delete Item
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Task<bool> DeleteItem(int productId);

        /// <summary>
        /// Get Product List
        /// </summary>
        /// <param name="takeCount"></param>
        /// <param name="skipCount"></param>
        /// <returns></returns>
        public Task<List<ProductList>> GetProductList(int takeCount, int skipCount);

        /// <summary>
        /// To get the detail of a product.
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Task<GetProductDetailResponse> GetProductById(int productId);

        /// <summary>
        /// Check if product exists or not.
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Task<bool> ProductExists(int productId);
    }
}
