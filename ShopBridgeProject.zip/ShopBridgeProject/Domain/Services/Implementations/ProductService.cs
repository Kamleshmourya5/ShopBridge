﻿using Microsoft.Extensions.Logging;
using Shopbridge_base.Common;
using Shopbridge_base.Common.HelperClass;
using Shopbridge_base.Data.Repository;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;

namespace Shopbridge_base.Domain.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<ProductService> _logger;
        public ProductService(IProductRepository productRepository, ILogger<ProductService> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }
        public async Task<int> AddNewItem(AddNewProductRequest productRequest)
        {
            try
            {
                var product = new Product
                {
                    Name = productRequest.Name,
                    Description = productRequest.Description,
                    Price = productRequest.Price,
                    Category = productRequest.Category,
                    CreatedDate = DateTime.UtcNow,
                    Status = (int)Enums.ProductStatus.Active
                };
                return await _productRepository.AddProduct(product);
            }
            catch(Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return 0;
            }
        }

        public async Task<bool> DeleteItem(int productId)
        {
            try
            {
                var product = await _productRepository.GetProductById(productId);
                product.Status = (int)Enums.ProductStatus.InActive;
                product.ModifiedDate = DateTime.UtcNow;
                return await _productRepository.UpdateProduct(product);
            }
            catch(Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return false;
            }
            
        }

        public async Task<GetProductDetailResponse> GetProductById(int productId)
        {
            try
            {
                var product = await _productRepository.GetProductById(productId);
                return new GetProductDetailResponse
                {
                    ProductId = product.ProductId,
                    Name = product.Name,
                    Description = product.Description,
                    Price = product.Price,
                    Category = Convert.ToString(EnumHelper.GetEnumTextValue<Enums.Category>(product.Category)),
                    CreatedDate = product.CreatedDate.ToLongDateString(),
                    ModifiedDate = product.ModifiedDate.ToLongDateString()
                };
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return (GetProductDetailResponse)null;
            }
            
        }

        public async Task<List<ProductList>> GetProductList(int takeCount, int skipCount)
        {
            return await _productRepository.GetProductList(takeCount,skipCount);
        }

        public async Task<bool> ProductExists(int productId)
        {
            return await _productRepository.ProductExists(productId);
        }

        public async Task<bool> UpdateItem(UpdateProductRequest productRequest)
        {
            try
            {
                var product = await _productRepository.GetProductById(productRequest.ProductId);
                product.ProductId = productRequest.ProductId;
                product.Name = !string.IsNullOrEmpty(productRequest.Name)? productRequest.Name: product.Name;
                product.Description = !string.IsNullOrEmpty(productRequest.Description) ? productRequest.Description : product.Description;
                product.Price = productRequest.Price > Convert.ToDecimal(0) ? productRequest.Price : product.Price;
                product.Category = productRequest.Category;
                product.ModifiedDate = DateTime.UtcNow;
                return await _productRepository.UpdateProduct(product);
            }
            catch(Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return false;
            }
        }
    }
}
