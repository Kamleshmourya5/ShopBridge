﻿using Shopbridge_base.Common;
using System.ComponentModel.DataAnnotations;

namespace Shopbridge_base.Domain.Models
{
    public class UpdateProductRequest
    {
        [Required]
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        [Required]
        [EnumDataType(typeof(Enums.Category), ErrorMessage = "Valid values are 1= Electronics, 2= Clothes.")]
        public int Category { get; set; }
    }
}
