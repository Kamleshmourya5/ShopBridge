﻿using Shopbridge_base.Common;
using System.ComponentModel.DataAnnotations;

namespace Shopbridge_base.Domain.Models
{
    public class AddNewProductRequest
    {
        [Required]
        [MaxLength(256)]
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }

        [Required]
        [EnumDataType(typeof(Enums.Category),ErrorMessage ="Valid values are 1= Electronics, 2= Clothes.")]
        public int Category { get; set; }
    }
}
