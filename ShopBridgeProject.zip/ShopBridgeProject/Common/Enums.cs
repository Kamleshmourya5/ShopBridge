﻿namespace Shopbridge_base.Common
{
    public static class Enums
    {
        public enum Category
        {
            Electronics = 1,
            Cloths = 2
        }
        public enum ProductStatus
        {
            Active =1,
            InActive =2
        }
    }
}
