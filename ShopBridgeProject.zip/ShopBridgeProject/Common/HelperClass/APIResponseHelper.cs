﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Common.HelperClass
{
    public class Result
    {
        public Object response { get; set; }
        public string message { get; set; }
        public int statusCode { get; set; }

        /// <summary>
        /// To return the result of the request.
        /// </summary>
        /// <param name="statusCode"></param>
        /// <param name="message"></param>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static Result Execute(int statusCode, string message, object obj = null)
        {
            return new Result { statusCode = statusCode, message = message, response = obj };
        }
    }
}
