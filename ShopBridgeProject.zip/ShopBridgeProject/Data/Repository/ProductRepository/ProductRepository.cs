﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Common;
using Shopbridge_base.Common.HelperClass;
using Shopbridge_base.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Data.Repository.ProductRepository
{
    public class ProductRepository : Repository, IProductRepository
    {
        private readonly ILogger<ProductRepository> logger;
        private readonly Shopbridge_Context _context;

        public ProductRepository(Shopbridge_Context context, ILogger<ProductRepository> _logger) : base(context)
        {
            this._context = context;
            logger = _logger;
        }

        public async Task<int> AddProduct(Product product)
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    await _context.Product.AddAsync(product);
                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    logger.LogInformation(ex.Message);
                }
                return product.ProductId;
            }
        }

        public async Task<bool> ProductExists(int productId)
        {
            try
            {
                return await _context.Product.AnyAsync(x => x.ProductId == productId && x.Status == (int)Enums.ProductStatus.Active);
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
                return false;
            }
        }

        public async Task<Product> GetProductById(int productId)
        {
            try
            {
                return await _context.Product.FirstOrDefaultAsync(x => x.ProductId == productId);
            }
            catch(Exception ex)
            {
                logger.LogInformation(ex.Message);
                return (Product)null;
            }
        }

        public async Task<List<ProductList>> GetProductList(int takeCount, int skipCount)
        {
            var products = new List<ProductList>();
            try
            {
                var productList = (from product in _context.Product
                                   where product.Status == (int)Enums.ProductStatus.Active
                                   select new ProductList
                                   {
                                       ProductId = product.ProductId,
                                       Name = product.Name,
                                       Description = product.Description,
                                       Price = product.Price,
                                       Category = Convert.ToString(EnumHelper.GetEnumTextValue<Enums.Category>(product.Category))
                                   }).OrderByDescending(y => y.ProductId);
                var totalCount = productList.Count();
                products = await productList.Skip(skipCount).Take(takeCount).ToListAsync();
                if (totalCount > 0 && products.Any())
                    products.FirstOrDefault().TotalRecord = totalCount;
            }
            catch(Exception ex)
            {
                logger.LogInformation(ex.Message);
            }
            return products;
        }

        public async Task<bool> UpdateProduct(Product product)
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    _context.Product.Update(product);
                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();
                    return true;
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    logger.LogInformation(ex.Message);
                    return false;
                }
            }
        }
    }
}
