﻿using Shopbridge_base.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Data.Repository
{
    public interface IProductRepository: IRepository<Product>
    {
        public Task<int> AddProduct(Product product);
        public Task<bool> UpdateProduct(Product product);
        public Task<List<ProductList>> GetProductList(int takeCount, int skipCount);
        public Task<Product> GetProductById(int productId);

        public Task<bool> ProductExists(int productId);
    }
}
